//Uncomment for debug 
//#define DEBUG

// LoRaWAN freq band
#define AS_923

